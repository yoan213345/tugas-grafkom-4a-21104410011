function setup() {
  createCanvas(640, 480);
}

function draw() {
  background(82,97,52);
}