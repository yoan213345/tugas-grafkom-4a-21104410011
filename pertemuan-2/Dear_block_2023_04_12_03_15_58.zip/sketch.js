function setup() {
  createCanvas(640, 480);
}

function draw() {
  //untuk bacround warna alphine green
  background(82,97,52);
  //membuat lingkaran di sisi kanan
  //fill berfungsi untuk memberikan warna di dalam lingkaran 
  fill(20,15,70);
  //stroke untuk memberi warna dan ketebalan pada garis tepi lingkaran
  stroke(255,255,0);
  //square untuk membuat lingkaran (posisi x/y, besar dan kecil)
  square(320,25,250,250);
  //membuat lingkaran di sisi kiri
  //fill berfungsi untuk memberi warna di dalam lingkaran
  fill(20,15,70);
  //stroke untuk memberi warna dan ketebalan pada garis tepi lingkaran
  stroke(255,255,0);
  //square untuk membuat lingkaran (posisi x/y, besar dan kecil)
  square(20,20,250,250)
}